package edu.ou.cs2334.project5.views;

import edu.ou.cs2334.project5.models.CellState;
import javafx.scene.layout.GridPane;
/**
 * This class is a GridPane that displays the cell states.
 * 
 * @author Thi Thuy Trang Tran
 * @version 0.1
 */
public class CellGridView extends GridPane{
	
	private final static String STYLE_CLASS = "cell-grid-view";
	private CellView[][] cellViews;
	
	/**
	 * Create a two-dimensional array of CellViews and add them to the GridPane 
	 * at the positions with the same row and column indices.
	 * 
	 * @param numRows the number of rows
	 * @param numCols the number of columns
	 * @param cellLength the length of cell
	 */
	public CellGridView(int numRows, int numCols, int cellLength) {
		initCells(numRows, numCols, cellLength);
		getStyleClass().add(STYLE_CLASS);
	}
	
	/**
	 * Initialize the cells of this view.
	 * 
	 * @param numRows the number of rows
	 * @param numCols the number of columns
	 * @param cellLength the length of cell
	 */
	public void initCells(int numRows, int numCols, int cellLength) {
		getChildren().clear();
		cellViews = new CellView[numRows][numCols];
		for(int i = 0; i < numRows; i++) {
			for(int j = 0; j < numCols; j++) {
				CellView a = new CellView(cellLength);
				add(a, j, i);
				cellViews[i][j] = a;
			}			
		}
	}
	
	/**
	 * Get the CellView using the given indices.
	 * 
	 * @param rowIdx the index of row
	 * @param colIdx the index of column
	 * @return CellView at given index
	 */
	public CellView getCellView(int rowIdx, int colIdx) {
		return cellViews[rowIdx][colIdx];
	}
	
	/**
	 * Update the state of the CellView with the given indices.
	 * 
	 * @param rowIdx the index of row
	 * @param colIdx the index of column
	 * @param state the CellState that need to update
	 */
	public void setCellState(int rowIdx, int colIdx, CellState state) {
		getCellView(rowIdx, colIdx).setState(state);
	}
}
