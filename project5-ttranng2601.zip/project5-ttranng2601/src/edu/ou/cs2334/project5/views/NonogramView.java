package edu.ou.cs2334.project5.views;

import edu.ou.cs2334.project5.models.CellState;
import edu.ou.cs2334.project5.views.clues.LeftCluesView;
import edu.ou.cs2334.project5.views.clues.TopCluesView;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
/**
 * This class is a BorderPane that displays the row clues in the left position, 
 * the column clues in the top position, and the cells in the middle position.
 * 
 * @author Thi Thuy Trang Tran
 * @version 0.1
 */
public class NonogramView extends BorderPane{
	
	private static final String STYLE_CLASS = "nonogram-view";
	private static final String SOLVED_STYLE_CLASS = "nonogram-view-solved";
	private LeftCluesView leftCluesView;
	private TopCluesView topCluesView;
	private CellGridView cellGridView;
	private HBox bottomHBox;
	private Button loadButton = new Button("Load");
	private Button resetButton = new Button("Reset");
	
	/**
	 * Construct a NonogramView instance by add the style class "nonogram-view"
	 */
	public NonogramView() {
		getStyleClass().add(STYLE_CLASS);
	}
	
	/**
	 * Construct and set the leftCluesView, topCluesView, and cellGridView instance variables
	 *  using the given parameters. Also, initialize HBox with the Load and Reset buttons
	 * 
	 * @param rowClues a 2D array stores clues of all rows
	 * @param colClues a 2D array stores clues of all columns
	 * @param cellLength the size of cell
	 */
	public void initialize(int[][] rowClues, int[][] colClues, int cellLength) {
		int rowCluesWidth = getCluesMaxLength(rowClues);
		int colCluesHeight = getCluesMaxLength(colClues);
		leftCluesView = new LeftCluesView(rowClues, cellLength, rowCluesWidth);
		topCluesView = new TopCluesView(colClues, cellLength, colCluesHeight);
		cellGridView = new CellGridView(rowClues.length, colClues.length, cellLength);
		
		initBottomHbox();
		
		setLeft(leftCluesView);
		setTop(topCluesView);
		setAlignment(topCluesView, Pos.TOP_RIGHT);
		setCenter(cellGridView);
		setBottom(bottomHBox);			
	}
	
	private int getCluesMaxLength (int[][] clues) {
		int length = clues[0].length;
		for(int i = 0; i < clues.length; i++) {
			if(clues[i].length > length)
				length = clues[i].length;
		}
		return length;
	}
	
	private void initBottomHbox() {
		bottomHBox = new HBox();
		bottomHBox.setAlignment(Pos.CENTER);
		bottomHBox.getChildren().addAll(getLoadButton(), getResetButton());	
	}
	
	/**
	 * Get CellView at given indices.
	 * 
	 * @param rowIdx the index of row
	 * @param colIdx the index of column
	 * @return return CellView associated with given indices
	 */
	public CellView getCellView (int rowIdx, int colIdx) {
		return cellGridView.getCellView(rowIdx, colIdx);
	}
	
	/**
	 * Update the state of the CellView with the given indices.
	 * 
	 * @param rowIdx the index of row
	 * @param colIdx the index of column
	 * @param state an enum represents state of cell
	 */
	public void setCellState(int rowIdx, int colIdx, CellState state) {
		cellGridView.setCellState(rowIdx, colIdx, state);
	}
	
	/**
	 * Update the state of the RowClueView with the given index.
	 * 
	 * @param rowIdx the index of row
	 * @param solved true if it solved or false if it's not
	 */
	public void setRowClueState(int rowIdx, boolean solved) {
		leftCluesView.setState(rowIdx, solved);
	}
	
	/**
	 * Update the state of the ColClueView with the given index.
	 * 
	 * @param colIdx the index of column
	 * @param solved true if it solved or false if it's not
	 */
	public void setColClueState(int colIdx, boolean solved) {
		topCluesView.setState(colIdx, solved);
	}
	
	/**
	 * If the puzzle is solved, add the solved style class. 
	 * Otherwise, remove all occurrences of this style class.
	 * 
	 * @param solved  true if it solved or false if it's not
	 */
	public void setPuzzleState(boolean solved) {
		if (solved == true)
			getStyleClass().add(SOLVED_STYLE_CLASS);
		else
			getStyleClass().remove(SOLVED_STYLE_CLASS);
	}
	
	/**
	 * Get the load button.
	 * 
	 * @return the load button
	 */
	public Button getLoadButton() {
		return loadButton;
	}
	
	/**
	 * Get the reset button.
	 * 
	 * @return the reset button.
	 */
	public Button getResetButton() {
		return resetButton;
	}
	
	/**
	 * Show a victory alert as shown in an earlier image.
	 */
	public void showVictoryAlert() {
		Alert victory = new Alert(AlertType.INFORMATION);
		victory.setTitle("Puzzle Solved");
		victory.setHeaderText("Congratulations!");
		victory.setContentText("You Win!");
		victory.showAndWait();
	}
	
}
