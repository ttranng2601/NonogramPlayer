package edu.ou.cs2334.project5.models;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * This class encapsulates the state and rules of the game. 
 * It stores arrays with the row clues, column clues, and cell states (EMPTY, FILLED, or MARKED).
 * 
 * @author Thi Thuy Trang Tran
 * @version 0.1
 * 
 */
public class NonogramModel {

	private static final String DELIMITER = " ";
	private static final int IDX_NUM_ROWS = 0;
	private static final int IDX_NUM_COLS = 1;

	private int[][] rowClues;
	private int[][] colClues;
	private CellState[][] cellStates;

	/**
	 * Initialize the object using the given arrays of row and column clues.
	 * 
	 * @param rowClues 2D array of clues of all rows
	 * @param colClues 2D array of clues of all rows
	 */
	public NonogramModel(int[][] rowClues, int[][] colClues) {
		this.rowClues = deepCopy(rowClues);
		this.colClues = deepCopy(colClues);

		cellStates = initCellStates(getNumRows(), getNumCols());
	}
	
	/**
	 * Initialize the object using the row and column clues in the given file.
	 * 
	 * @param file the text file contains puzzle
	 * @throws IOException if the file is not recognized
	 */
	public NonogramModel(File file) throws IOException {
		// Number of rows and columns
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String header = reader.readLine();
		String[] fields = header.split(DELIMITER);
		int numRows = Integer.parseInt(fields[IDX_NUM_ROWS]);
		int numCols = Integer.parseInt(fields[IDX_NUM_COLS]);

		// Initialize cellStates.
		cellStates = initCellStates(numRows, numCols);

		// Read in row clues.
		this.rowClues = readClueLines(reader, numRows);

		// Read in column clues.
		this.colClues = readClueLines(reader, numCols);
		// Close reader
		reader.close();
		}
	
	/**
	 * Initialize the object using the row and column clues in the text file with the given name.
	 * 
	 * @param filename the name of a file
	 * @throws IOException if the file is not recognized
	 */
	public NonogramModel(String filename) throws IOException {
		this(new File(filename));
	}

	/**
	 * Get the number of rows in the nonogram.
	 * 
	 * @return an integer is the number of rows
	 */
	public int getNumRows() {
		return rowClues.length;
	}

	/**
	 * Get the number of columns in the nonogram.
	 * 
	 * @return an integer is the number of columns
	 */
	public int getNumCols() {
		return colClues.length;
	}

	/**
	 * Get the state of the cell with the given row and column indices.
	 * 
	 * @param rowIdx index of row
	 * @param colIdx index of column
	 * @return the state of a cell
	 */
	public CellState getCellState(int rowIdx, int colIdx) {
		return cellStates[rowIdx][colIdx];
	}

	/**
	 * Return the boolean state of the cell with the given row and column indices.
	 * 
	 * @param rowIdx the index of row
	 * @param colIdx the index of column
	 * @return a boolean value true if CellState is filled or false if it is empty or marked
	 */
	public boolean getCellStateAsBoolean(int rowIdx, int colIdx) {
		return CellState.toBoolean(getCellState(rowIdx, colIdx));
	}
	
	/**
	 * Set the state of the cell with the given indices. 
	 * 
	 * @param rowIdx index of row
	 * @param colIdx index of column
	 * @param state state need to set
	 * @return a boolean value that indices whether the state of the puzzle changed
	 */
	public boolean setCellState(int rowIdx, int colIdx, CellState state) {
		if (state == null || isSolved() == true || state.equals(cellStates[rowIdx][colIdx])) {
			return false;
		} else {
			cellStates[rowIdx][colIdx] = state;
			return true;
		}
	}

	/**
	 * Return a deep copy of the row clues.
	 * 
	 * @return an 2D int array stores clues of rows
	 */
	public int[][] getRowClues() {
		return deepCopy(rowClues);
	}

	/**
	 * Return a deep copy of the column clues.
	 * 
	 * @return an 2D int array stores clues of columns
	 */
	public int[][] getColClues() {
		return deepCopy(colClues);
	}

	/**
	 * Return a copy of the row clue with the given index.
	 * 
	 * @param rowIdx the index of row
	 * @return an integer array stores clues of a row
	 */
	public int[] getRowClue(int rowIdx) {
		return Arrays.copyOf(rowClues[rowIdx], rowClues[rowIdx].length);
	}

	/**
	 * Return a copy of the column clue with the given index.
	 * 
	 * @param colIdx the index of column
	 * @return an integer array stores clues of a column
	 */
	public int[] getColClue(int colIdx) {
		return Arrays.copyOf(colClues[colIdx], colClues[colIdx].length);
	}

	/**
	 * Check if the row with the given index is solved
	 * 
	 * @param rowIdx the index of row
	 * @return true if the row with the given index is solved
	 */
	public boolean isRowSolved(int rowIdx) {
		if (Arrays.equals(rowClues[rowIdx], projectCellStatesRow(rowIdx)))
			return true;
		else
			return false;
	}

	/**
	 * Check if the column with the given index is solved
	 * 
	 * @param colIdx the index of column
	 * @return true if the column with the given index is solved
	 */
	public boolean isColSolved(int colIdx) {
		if (Arrays.equals(colClues[colIdx], projectCellStatesCol(colIdx)))
			return true;
		else
			return false;
	}

	/**
	 * Check if the puzzle is solved. 
	 * 
	 * @return Return true if the puzzle is solved; otherwise, return false
	 */
	public boolean isSolved() {
		boolean value = false;
		for (int i = 0; i < cellStates.length; i++) {
			for (int j = 0; j < cellStates[i].length; j++) {
				if (isColSolved(j) == true && isRowSolved(i) == true)
					value = true;
				else {
					value = false;
					break;
				}
			}
		}
		return value;
	}

	/**
	 * Change the state of all cells to EMPTY.
	 */
	public void resetCells() {
		for (int rowIdx = 0; rowIdx < getNumRows(); ++rowIdx) {
			for (int colIdx = 0; colIdx < getNumCols(); ++colIdx) {
				cellStates[rowIdx][colIdx] = CellState.EMPTY;
			}
		}
	}

	/**
	 * Return the nonogram numbers of the given array of cell state
	 * 
	 * @param cells a boolean array of cell states
	 * @return an int array stores nonogram number
	 */
	public static int[] project(boolean[] cells) {
		List<Integer> nonogramNums = new ArrayList<>();
		for (int i = 0; i < cells.length; i++) {
			if (cells[i] == true) {
				int count = 1;
				while (i + 1 < cells.length && cells[i] == cells[i + 1]) {
					i++;
					count++;
				}
				nonogramNums.add(count);
			}
		}
		if (nonogramNums.size() == 0)
			nonogramNums.add(0);
		return convertToPrimitiveArray(nonogramNums);
	}

	/**
	 * Return the projection of the cellStates row with the given index.
	 *
	 * @param rowIdx the index of row
	 * @return an int array stores nonogram number of a row
	 */
	public int[] projectCellStatesRow(int rowIdx) {
		boolean[] cellStateRow = new boolean[cellStates[rowIdx].length];
		for (int i = 0; i < cellStates[rowIdx].length; i++) {
			cellStateRow[i] = getCellStateAsBoolean(rowIdx, i);
		}
		return project(cellStateRow);
	}

	/**
	 * Return the projection of the cellStates column with the given index.
	 * 
	 * @param colIdx the index of column
	 * @return an int array stores nonogram number of a column
	 */
	public int[] projectCellStatesCol(int colIdx) {
		boolean[] cellStateCol = new boolean[cellStates.length];
		for (int i = 0; i < cellStates.length; i++) {
			cellStateCol[i] = getCellStateAsBoolean(i, colIdx);
		}
		return project(cellStateCol);
	}

	// This is implemented for you
	private static CellState[][] initCellStates(int numRows, int numCols) {
		// Create a 2D array to store numRows * numCols elements
		CellState[][] cellStates = new CellState[numRows][numCols];

		// Set each element of the array to empty
		for (int rowIdx = 0; rowIdx < numRows; ++rowIdx) {
			for (int colIdx = 0; colIdx < numCols; ++colIdx) {
				cellStates[rowIdx][colIdx] = CellState.EMPTY;
			}
		}

		// Return the result
		return cellStates;
	}

	// TODO: Implement this method
	private static int[][] deepCopy(int[][] array) {
		int[][] copiedArray = new int[array.length][];
		for (int i = 0; i < array.length; i++) {
			copiedArray[i] = Arrays.copyOf(array[i], array[i].length);
		}
		return copiedArray;
	}

	// This method is implemented for you. You need to figure out how it is useful.
	private static int[][] readClueLines(BufferedReader reader, int numLines) throws IOException {
		// Create a new 2D array to store the clues
		int[][] clueLines = new int[numLines][];

		// Read in clues line-by-line and add them to the array
		for (int lineNum = 0; lineNum < numLines; ++lineNum) {
			// Read in a line
			String line = reader.readLine();

			// Split the line according to the delimiter character
			String[] tokens = line.split(DELIMITER);

			// Create new int array to store the clues in
			int[] clues = new int[tokens.length];
			for (int idx = 0; idx < tokens.length; ++idx) {
				clues[idx] = Integer.parseInt(tokens[idx]);
			}

			// Store the processed clues in the resulting 2D array
			clueLines[lineNum] = clues;
		}

		// Return the result
		return clueLines;
	}

	private static int[] convertToPrimitiveArray(List<Integer> intList) {
		int[] array = new int[intList.size()];
		int i = 0;
		for (Integer a : intList) {
			array[i] = a;
			i++;
		}
		return array;
	}
}
