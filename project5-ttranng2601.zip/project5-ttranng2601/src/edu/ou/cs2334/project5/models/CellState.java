package edu.ou.cs2334.project5.models;

/**
 * This class represents the state of the NonogramModel grid.
 * @author Thi Thuy Trang Tran
 * @version 0.1
 */
public enum CellState {
	/** This enum represents an empty cell */
	EMPTY(),
	/** This enum represents a filled cell */
	FILLED(),
	/** This enum represents an X'd out cell */
	MARKED();

	/**
	 * A public static helper method to change CellState to boolean.
	 * @param state an enum of cell
	 * @return true if the state is filled and false if state is empty or marked
	 */
	public static boolean toBoolean(CellState state) {
		if(state == FILLED)
			return true;
		else
			return false;
	}
	
}
