package edu.ou.cs2334.project5;

import java.io.IOException;
import java.util.List;

import edu.ou.cs2334.project5.presenters.NonogramPresenter;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * A driver class extends Application and creates the application window and 
 * has methods to display the options menu and the puzzle maker.
 * 
 * @author Thi Thuy Trang Tran
 * @version 0.1
 */
public class Main extends Application {

	private static final int IDX_CELL_SIZE = 0;
	private static final int DEFAULT_CELL_SIZE = 30;

	/** 
	 * Launch the application.
	 * @param args arguments of class
	 */
	public static void main(String[] args) {
		launch(args);
	}

	/**
	 * Start the application
	 * @param primaryStage the window that displays the application content
	 */
	@Override
	public void start(Stage primaryStage) throws IOException {
		NonogramPresenter presenter;

		try {
			List<String> paraList = getParameters().getRaw();
			presenter = new NonogramPresenter(Integer.valueOf(paraList.get(IDX_CELL_SIZE)));
		} catch (IndexOutOfBoundsException e) {
			presenter = new NonogramPresenter(DEFAULT_CELL_SIZE);
		}

		Scene scene = new Scene(presenter.getPane());
		scene.getStylesheets().add("style.css");

		primaryStage.setScene(scene);
		primaryStage.setTitle("Nonograms ++");
		primaryStage.setResizable(false);
		primaryStage.show();

	}

}
