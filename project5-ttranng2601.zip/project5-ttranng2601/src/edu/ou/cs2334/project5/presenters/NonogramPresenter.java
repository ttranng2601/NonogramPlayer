package edu.ou.cs2334.project5.presenters;

import java.io.File;
import java.io.IOException;

import edu.ou.cs2334.project5.handlers.OpenHandler;
import edu.ou.cs2334.project5.interfaces.Openable;
import edu.ou.cs2334.project5.models.CellState;
import edu.ou.cs2334.project5.models.NonogramModel;
import edu.ou.cs2334.project5.views.NonogramView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Window;
import javafx.stage.FileChooser.ExtensionFilter;
/**
 * The class represents the brain of our program. 
 * The graphical view and model data are connected and synchronized by the presenter.
 * 
 * @author Thi Thuy Trang Tran
 * @version 0.1
 */
public class NonogramPresenter implements Openable {
	private NonogramView view;
	private NonogramModel model;
	private int cellLength;
	private static final String DEFAULT_PUZZLE = "puzzles/space-invader.txt";
	
	/**
	 * Construct a new NonogramModel instance using the DEFAULT_PUZZLE and 
	 * assign it to the instance variable.
	 * 
	 * @param cellLength the length of a cell
	 * @throws IOException if the file is not recognized
	 */
	public NonogramPresenter(int cellLength) throws IOException  {
		model = new NonogramModel(DEFAULT_PUZZLE);
		view = new NonogramView();
		this.cellLength = cellLength;	
		initializePresenter();		
	}
	
	private void initializePresenter() {
		initializeView();
		bindCellViews();
		synchronize();
		configureButtons();
	}
	
	private void initializeView() {
		view.initialize(model.getRowClues(), model.getColClues(), cellLength);	
		if(getWindow() != null) 
			getWindow().sizeToScene();
	}
	
	private void bindCellViews() {
		for(int i = 0; i < model.getNumRows(); ++i) {
			for (int j = 0; j < model.getNumCols(); j++) {
				int rowIdx = i;
				int colIdx = j;
				view.getCellView(i, j).setOnMouseClicked(event -> {
					 if (event.getButton() == MouseButton.PRIMARY)
						 handleLeftClicked(rowIdx, colIdx);
					 else if(event.getButton() == MouseButton.SECONDARY)
						 handleRightClicked(rowIdx, colIdx);
					 });
			}
		}
	}
	
	private void handleLeftClicked (int rowIdx, int colIdx) {
		CellState cellState = model.getCellState(rowIdx, colIdx);
		if(cellState == CellState.EMPTY || cellState == CellState.MARKED) 
			updateCellState(rowIdx, colIdx, CellState.FILLED);
		else 
			updateCellState(rowIdx, colIdx, CellState.EMPTY);
		
	}
	
	private void handleRightClicked (int rowIdx, int colIdx) {
		CellState cellState = model.getCellState(rowIdx, colIdx);
		if(cellState == CellState.EMPTY || cellState == CellState.FILLED) 
			updateCellState(rowIdx, colIdx, CellState.MARKED);
		
		else 
			updateCellState(rowIdx, colIdx, CellState.EMPTY);			
	}
	
	private void updateCellState (int rowIdx, int colIdx, CellState state) {	
		if(model.setCellState(rowIdx, colIdx, state) == true) {
			view.setCellState(rowIdx, colIdx, state);
			view.setRowClueState(rowIdx, model.isRowSolved(rowIdx));
			view.setColClueState(colIdx, model.isColSolved(colIdx));
			if(model.isSolved() == true)
				processVictory();
		} 		
	}
	
	private void synchronize() {
		
		for(int i =0; i < model.getNumRows(); i++) {
			view.setRowClueState(i, model.isRowSolved(i));
			for(int j = 0; j < model.getNumCols(); j++) {
				view.setCellState(i, j, model.getCellState(i, j));
				view.setColClueState(j, model.isColSolved(j));
			}
		}
		view.setPuzzleState(model.isSolved());
		if(model.isSolved() == true)
			processVictory();	
	}
	
	private void processVictory() {
		removeCellViewMarks();
		view.showVictoryAlert();
	}
	
	private void removeCellViewMarks() {
		for(int i = 0; i < model.getNumRows(); i++) {
			for (int j = 0; j < model.getNumCols(); j++) {
				if(model.getCellState(i, j) == CellState.MARKED)
						view.setCellState(i, j, CellState.EMPTY);
			}
		}		
	}
	
	private void configureButtons() {
		FileChooser fileChooserOpen = new FileChooser();
		fileChooserOpen.setTitle("Open");
		fileChooserOpen.getExtensionFilters().addAll(new ExtensionFilter("Text Files", "*.txt"));
		fileChooserOpen.setInitialDirectory(new File("."));
		view.getLoadButton().setOnAction(new OpenHandler(getWindow(), fileChooserOpen, this));
		
		view.getResetButton().setOnAction(e -> resetPuzzle());
	}
	
	/**
	 * Clear the model using the reset method and synchronize the model/view.
	 */
	public void resetPuzzle() {
		model.resetCells();
		synchronize();
	}
	
	/**
	 * Get the pane associated with this presenter.
	 * 
	 * @return an associated pane
	 */
	public Pane getPane() {
		return view;
	}
	
	/**
	 * Get the window associated with this presenter.
	 * 
	 * @return an associated window
	 */
	public Window getWindow() {
		try {
			return view.getScene().getWindow();
		} catch(NullPointerException e) {
			return null;
		}
	}
	
	/**
	 * Open a file contains model data.
	 * 
	 * @param file a text file
	 * @throws IOException if the file is not recognized
	 */
	@Override
	public void open(File file) throws IOException {
		model = new NonogramModel(file);
		initializePresenter();
	}
}
