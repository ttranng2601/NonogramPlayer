package edu.ou.cs2334.project4.handlers;

import java.io.File;
import java.io.IOException;

import edu.ou.cs2334.project4.interfaces.Openable;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.stage.FileChooser;
import javafx.stage.Window;
import javafx.stage.FileChooser.ExtensionFilter;

/**
 * This class handle the Action Event when users click Open on the menu.
 * 
 * @author Thi Thuy Trang Tran
 * @version 0.1
 */
public class OpenHandler extends AbstractBaseHandler implements EventHandler {

	private Openable opener;

	/** 
	 * Construct a handler for opening event
	 * 
	 * @param window the window from user
	 * @param fileChooser a dialog window from which user can select a file to open
	 * @param opener an instance of Openable interface that allows OpenHandler handle file opening
	 */
	public OpenHandler(Window window, FileChooser fileChooser, Openable opener) {
		super(window, fileChooser);
		this.opener = opener;
	}

	/**
	 * Handle the event by opening the open dialog to user.
	 * 
	 * @param e the event from user
	 */
	@Override
	public void handle(Event e) {
		File selectedFile = fileChooser.showOpenDialog(window);

		try {
			opener.open(selectedFile);
		} catch (IOException e1) {

			e1.printStackTrace();
		}

	}
}
