package edu.ou.cs2334.project4.handlers;

import edu.ou.cs2334.project4.models.NonogramMakerModel;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.ToggleButton;

/**
 * This class handles an Action Event when user clicks the button to draw an image.
 * 
 * @author Thi Thuy Trang Tran
 * @version 0.1
 *
 */
public class ToggleButtonEventHandler implements EventHandler<ActionEvent>{
	
	private NonogramMakerModel model;
	private int rowIdx;
	private int colIdx;
	private ToggleButton button;
	
	/**
	 * Construct a handler for action when the user clicks the button to draw an image.
	 * 
	 * @param model nanogram model 
	 * @param rowIdx the row index
	 * @param colIdx the column index
	 */
	public ToggleButtonEventHandler (NonogramMakerModel model, int rowIdx, int colIdx) {
		this.model = model;
		this.rowIdx = rowIdx;
		this.colIdx = colIdx;
	}

	/**
	 * Handle the event by changing state of button when user clicks the button.
	 * 
	 * @param event the event from user
	 */
	@Override
	public void handle(ActionEvent event) {
		button = (ToggleButton) event.getSource();
		model.setCell(rowIdx, colIdx, button.isSelected());			
	}

}
