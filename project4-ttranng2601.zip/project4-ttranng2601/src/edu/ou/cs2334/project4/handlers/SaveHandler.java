package edu.ou.cs2334.project4.handlers;

import java.io.File;
import java.io.IOException;

import edu.ou.cs2334.project4.interfaces.Saveable;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Window;

/**
 * This class handle the Action Event when users click Save on the menu.
 * 
 * @author Thi Thuy Trang Tran
 * @version 0.1
 *
 */
public class SaveHandler extends AbstractBaseHandler implements EventHandler {

	private Saveable saver;

	/**
	 * Construct a handler for saving event
	 * 
	 * @param window the window from user
	 * @param fileChooser a dialog window from which user can choose where to save and name of file
	 * @param saver an instance of Saveable interface that allows SaveHandler handle file saving
	 */
	public SaveHandler(Window window, FileChooser fileChooser, Saveable saver) {
		super(window, fileChooser);
		this.saver = saver;
	}

	/**
	 * Handle the event by opening the save dialog to user.
	 * 
	 * @param arg0 the event from user
	 */
	@Override
	public void handle(Event arg0) {
		File file = fileChooser.showSaveDialog(window);
		try {
			saver.save(file.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
