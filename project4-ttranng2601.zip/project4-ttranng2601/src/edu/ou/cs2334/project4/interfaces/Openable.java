package edu.ou.cs2334.project4.interfaces;

import java.io.File;
import java.io.IOException;

/**
 * An interface allows the OpenHandler class to handle file opening.
 * 
 * @author Thi Thuy Trang Tran
 * @version 0.1
 */
public interface Openable {
	/**
	 * Method to handle opening a file
	 * @param file a file needs to open
	 * @throws IOException if the file is not recognized
	 */
	void open (File file) throws IOException;
}
