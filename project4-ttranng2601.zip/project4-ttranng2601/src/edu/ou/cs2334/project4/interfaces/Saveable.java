package edu.ou.cs2334.project4.interfaces;

import java.io.IOException;

/**
 * An interface allows the SaveHandler class to handle file saving
 * @author Thi Thuy Trang Tran
 * @version 0.1
 */
public interface Saveable {
/**
 * Method to handle saving a file
 * @param filename name of file
 * @throws IOException if the file is not recognized
 */
	void save(String filename) throws IOException;
}
