package edu.ou.cs2334.project4.views;

import java.util.HashMap;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
/**
 * This class creates a BorderPane with a graphical interface for the puzzle maker.
 * 
 * @author Thi Thuy Trang Tran
 * @version 0.1
 */
public class NonogramMakerView {
	private BorderPane borderPane;
	private MenuBar menuBar;
	private CellGridView cellGridView;
	private HashMap<String, MenuItem> menuItemsMap = new HashMap<>();;
	
	/** String of Open menu item */
	public static String MENU_ITEM_OPEN = "MENU_ITEM_OPEN";
	/** String of Save menu item */
	public static String MENU_ITEM_SAVE = "MENU_ITEM_SAVE";
	/** String of Exit menu item */
	public static String MENU_ITEM_EXIT = "MENU_ITEM_EXIT";
	
	/**
	 * Construct a NonogramMakerView
	 * 
	 * @param numRows the number of rows
	 * @param numCols the number of columns
	 * @param cellLength the size of button
	 */
	public NonogramMakerView(int numRows, int numCols, int cellLength) {
		borderPane = new BorderPane();
		cellGridView = new CellGridView(numRows, numCols, cellLength);
		initMenuBar();
		borderPane.setCenter(cellGridView.getPane());
		borderPane.setTop(menuBar);
	}
	
	private void initMenuBar() {
		Menu menu = new Menu ("_File");
		
		MenuItem menuItem1 = new MenuItem("_Open");
		MenuItem menuItem2 = new MenuItem("_Save");
		MenuItem menuItem3 = new MenuItem("_Exit");
		menu.getItems().addAll(menuItem1, menuItem2, menuItem3);
		
		menuItemsMap.put(MENU_ITEM_OPEN, menuItem1);
		menuItemsMap.put(MENU_ITEM_SAVE, menuItem2);
		menuItemsMap.put(MENU_ITEM_EXIT, menuItem3);
		
		menuItem3.setOnAction((ActionEvent e) -> {Platform.exit();});
		
		menuBar = new MenuBar();
		menuBar.getMenus().add(menu);	
	}
	
	/**
	 * Return the MenuItem associated with a given key String. 
	 * 
	 * @param name the name of Menu Item
	 * @return MenuItem related to given key String
	 */
	public MenuItem getMenuItem (String name) {
		return menuItemsMap.get(name);
	}
	
	/**
	 * Return the pane associated with this view.
	 * 
	 * @return a pane of this view
	 */
	public Pane getPane() {
		return borderPane;
	}
	
	/**
	 * Creates buttons according to the given parameters.
	 * 
	 * @param numRows the number of rows
	 * @param numCols the number of columns
	 * @param cellLength the size of button
	 */
	public void initButton (int numRows, int numCols, int cellLength) {
		cellGridView.initButtons(numRows, numCols, cellLength);
	}
	
	/**
	 * Return the toggleButton at a given position.
	 * @param row the row index
	 * @param col the column index
	 * @return the Toggle Button at a given index
	 */
	public ToggleButton getToggleButton (int row, int col) {
		return cellGridView.getToggleButton(row, col);
	}
	
	/** 
	 * Return the number of rows
	 * @return the number of rows
	 */
	public int getNumRows() {
		return cellGridView.getNumRows();
	}
	
	/**
	 * Return the number of columns
	 * @return the number of columns
	 */
	public int getNumCols() {
		return cellGridView.getNumCols();
	}
}
