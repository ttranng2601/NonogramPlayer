package edu.ou.cs2334.project4.views;

import java.util.ArrayList;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

/**
 * This class creates a GridPane of ToggleButtons that is the primary component of the puzzle maker interface
 * 
 * @author Thi Thuy Trang Tran
 * @version 0.1
 * 
 */
public class CellGridView {
	
	private ArrayList <ToggleButton> gridButton = new ArrayList<>();
	private GridPane gridPane = new GridPane();
	private int numRows;
	private int numCols;
	
	/**
	 * Construct a gridPane of toggle buttons with given parameters.
	 * 
	 * @param numRows the number of rows
	 * @param numCols the number of column
	 * @param cellLength the size of a button
	 */
	public CellGridView (int numRows, int numCols, int cellLength) {
		this.numRows = numRows;
		this.numCols = numCols;
		gridPane.setPadding(new Insets(10, 10, 10, 10));
		gridPane.setAlignment(Pos.CENTER);	
		initButtons (this.numRows,this.numCols, cellLength);		
	}
	
	/**
	 * Creates buttons according to the given parameters.
	 * 
	 * @param numRows the number of rows
	 * @param numCols the number of columns
	 * @param cellLength the size of a button
	 */
	public void initButtons (int numRows, int numCols, int cellLength) {
		this.numRows = numRows;
		this.numCols = numCols;
		gridButton.clear();
		gridPane.getChildren().clear();
		
		for( int i = 0; i < numRows; i++) {
			for(int j = 0; j < numCols; j++) {
				ToggleButton button = new ToggleButton();
				button.setMaxWidth(cellLength);
				button.setMinWidth(cellLength);
				button.setPrefWidth(cellLength);
				button.setMaxHeight(cellLength);
				button.setMinHeight(cellLength);
				button.setPrefHeight(cellLength);
				gridButton.add(button);
				gridPane.add(button, j, i);
			}	
		}	
		
	}
	
	/**
	 * Get the number of rows. 
	 * 
	 * @return an integer value of number of rows
	 */
	public int getNumRows() {
		return numRows;
	}
	
	/**
	 * Get the number of columns.
	 * 
	 * @return an integer value of number of columns
	 */
	public int getNumCols() {
		return numCols;
	}
	
	/**
	 * Return Toggle Button at a given position.
	 * 
	 * @param row the row index
	 * @param col the column index
	 * @return a toggle button 
	 */
	public ToggleButton getToggleButton (int row, int col) {
		int index = row * numCols + col;
		return gridButton.get(index);
	}
	
	/**
	 * Return the pane associated with this view.
	 * 
	 * @return the pane associated with this view
	 */
	public Pane getPane() {
		return gridPane;
	}
	
}
