package edu.ou.cs2334.project4.presenters;

import java.io.File;
import java.io.IOException;

import edu.ou.cs2334.project4.handlers.OpenHandler;
import edu.ou.cs2334.project4.handlers.SaveHandler;
import edu.ou.cs2334.project4.handlers.ToggleButtonEventHandler;
import edu.ou.cs2334.project4.interfaces.Openable;
import edu.ou.cs2334.project4.interfaces.Saveable;
import edu.ou.cs2334.project4.models.NonogramMakerModel;
import edu.ou.cs2334.project4.views.NonogramMakerView;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.stage.Window;
/**
 * This class connects the graphical view and model data.
 * 
 * @author Thi Thuy Trang Tran
 * @version 0.1
 */
public class NonogramMakerPresenter implements Openable, Saveable{
	
	private NonogramMakerView view;
	private NonogramMakerModel model;
	private int cellLength;
	
	/**
	 * Create a presenter to connect model data and graphic view.
	 * 
	 * @param numRows the number of rows
	 * @param numCols the number of columns
	 * @param cellLength the size of button
	 */
	public NonogramMakerPresenter (int numRows, int numCols, int cellLength) {
		model = new NonogramMakerModel(numRows, numCols);
		view = new NonogramMakerView(numRows, numCols, cellLength);
		this.cellLength = cellLength;
		init();
	}
	
	private Window getWindow() {
		try {
			return view.getPane().getScene().getWindow();
		} catch(NullPointerException e) {
			return null;
		}	
	}
	
	private void init() {
		initToggleButtons();
		bindToggleButtons();
		configureMenuItems();	
	}
	
	private void initToggleButtons() {
		view.initButton(model.getNumRows(), model.getNumCols(), cellLength);
		if(getWindow() != null) 
			getWindow().sizeToScene();
	}
	
	private void bindToggleButtons() {
		int numRow = model.getNumRows();
		int numCol = model.getNumCols();
		for(int i = 0; i < numRow; i++) {
			for(int j = 0; j < numCol; j++) {
				view.getToggleButton(i, j).setSelected(model.getCell(i, j)); {
				view.getToggleButton(i, j).setOnAction(new ToggleButtonEventHandler(model, i, j));
				}
			}
		}
	}
	
	private void configureMenuItems() {
		FileChooser fileChooserOpen = new FileChooser();
		fileChooserOpen.setTitle("Open");
		fileChooserOpen.getExtensionFilters().addAll(new ExtensionFilter("Text Files", "*.txt"));
		fileChooserOpen.setInitialDirectory(new File("."));
		view.getMenuItem(NonogramMakerView.MENU_ITEM_OPEN)
			.setOnAction(new OpenHandler(getWindow(), fileChooserOpen, this));
		
		FileChooser fileChooserClose = new FileChooser();
		fileChooserClose.setTitle("Save");
		fileChooserClose.getExtensionFilters().addAll(new ExtensionFilter("Text Files", "*.txt"));
		view.getMenuItem(NonogramMakerView.MENU_ITEM_SAVE)
			.setOnAction(new SaveHandler(getWindow(), fileChooserClose, this));
	}
	
	/**
	 * Return the pane associated with the view.
	 * 
	 * @return a Pane of this view
	 */
	public Pane getPane() {
		return view.getPane();
	}
	
	
	/**
	 * Open a file contains model data.
	 * 
	 * @param file a text file
	 * @throws IOException if the file is not recognized
	 */
	@Override
	public void open (File file) throws IOException  {
		model =  new NonogramMakerModel(file);
		init();
	}
	
	/**
	 * Save user input data.
	 * 
	 * @param filename the name of file
	 * @throws IOException if the file is not recognized
	 */
	@Override
	public void save (String filename) throws IOException {
		model.saveToFile(filename);
	}

}
