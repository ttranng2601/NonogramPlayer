package edu.ou.cs2334.project4.models;

import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.StringJoiner;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * This class contains the functionality of the puzzle maker which is independent of the graphical interface.
 * 
 * @author Thi Thuy Trang Tran
 * @version 0.1
 */
public class NonogramMakerModel {

	private static final char EMPTY_CELL_CHAR = '0';
	private static final char FILLED_CELL_CHAR = '1';

	private int numRows;
	private int numCols;
	private boolean[] grid;

	/**
	 * Create a 1D boolean array with the given number of rows and columns.
	 * 
	 * @param numRows the number of rows of puzzle
	 * @param numCols the number of column of puzzle
	 * @throws IllegalArgumentException if the number of rows and columns are less than zero
	 */
	public NonogramMakerModel(int numRows, int numCols) throws IllegalArgumentException {
		if (numRows <= 0 || numCols <= 0)
			throw new IllegalArgumentException();
		else {
			this.numRows = numRows;
			this.numCols = numCols;
			grid = new boolean[this.numRows * this.numCols];
		}
	}

	/**
	 * Construct a NonogramMakerModel by reading in data from a file.
	 * 
	 * @param file the text file contains puzzle
	 * @throws IOException if the file is not recognized
	 */
	public NonogramMakerModel(File file) throws IOException {

		Scanner scnr = new Scanner(file);

		numRows = scnr.nextInt();
		numCols = scnr.nextInt();
		grid = new boolean[numCols * numRows];
		List<String> lines = Files.readAllLines(file.toPath());

		List<Boolean> grid = new ArrayList<>();
		for (int i = numCols + numRows + 1; i < lines.size(); i++) {
			for (int j = 0; j < lines.get(i).length(); j++) {
				if (lines.get(i).charAt(j) == EMPTY_CELL_CHAR)
					grid.add(false);
				else
					grid.add(true);
			}
		}
		
		this.grid = convertToPrimitiveArray(grid);
	}
	
	/**
	 * Construct a NonogramMakerModel by reading in data from a file given a filename.
	 * 
	 * @param filename the name of a file 
	 * @throws IOException if the file is not recognized
	 */
	public NonogramMakerModel(String filename) throws IOException {
		this(new File(filename));
	}
	
	/**
	 * Get the grid array variable.
	 * 
	 * @return a copy of the grid array
	 */
	public boolean[] getGrid() {
		return Arrays.copyOf(grid, grid.length);
	}

	/**
	 * Return the cell state at a given position.
	 * 
	 * @param rowIdx the index of row
	 * @param colIdx the index of column
	 * @return boolean value at given position
	 */
	public boolean getCell(int rowIdx, int colIdx) {
		int index = rowIdx * numCols + colIdx;
		return grid[index];
	}

	/**
	 * Update the cell state at a given position.
	 * 
	 * @param rowIdx the index of row
	 * @param colIdx the index of column
	 * @param state the state of cell that need to update
	 */
	public void setCell(int rowIdx, int colIdx, boolean state) {
		int index = rowIdx * numCols + colIdx;
		grid[index] = state;
	}
	
	/**
	 * Return the number of grid rows.
	 * 
	 * @return the integer value of the number of rows
	 */
	public int getNumRows() {
		return numRows;
	}

	/**
	 * Return the number of grid column.
	 * 
	 * @return the integer value of the number of columns
	 */
	public int getNumCols() {
		return numCols;
	}

	/**
	 * Return the nonogram numbers of the given array of cell states.
	 * 
	 * @param cells the boolean array stores cell states
	 * @return a List of nonogram numbers
	 */
	public static List<Integer> project(boolean[] cells) {
		List<Integer> nonogramNums = new ArrayList<>();
		for (int i = 0; i < cells.length; i++) {
			if (cells[i] == true) {
				int count = 1;
				while (i + 1 < cells.length && cells[i] == cells[i + 1]) {
					i++;
					count++;
				}
				nonogramNums.add(count);
			}
		}
		if (nonogramNums.size() == 0)
			nonogramNums.add(0);
		return nonogramNums;
	}

	/**
	 * Return the projection of the row with the given index.
	 * 
	 * @param rowIdx the index of row needed to project
	 * @return a List of nonogram numbers at given index row
	 */
	public List<Integer> projectRow(int rowIdx) {
		boolean[] rowCells = Arrays.copyOfRange(grid, rowIdx * numCols, (rowIdx + 1) * numCols);
		return project(rowCells);
	}

	/**
	 * Return the projection of the column with the given index.
	 * 
	 * @param colIdx the index of column needed to project
	 * @return a List of nonogram numbers at given index column
	 */
	public List<Integer> projectCol (int colIdx) {					//TA:Ethan Ho
		return project(
		        convertToPrimitiveArray(
		            IntStream.range(0, grid.length)   				// Get a stream (like a list) of ints corresponding to grid indicies
		                .filter(idx -> (idx % numCols) == colIdx)   // Filter the stream so it only corresponds to indicies in colIdx
		            		.mapToObj(idx -> grid[idx])   			// Use those indices to get the corresponding boolean elements
		             	    	.collect(Collectors.toList())));	// Convert that stream to a List<Boolean> (which later becomes boolean[])
	}
	
	/**
	 * Save the output of toString to a text file with the given name.
	 * 
	 * @param filename the file name that need to save
	 * @throws IOException the file is not recognized
	 */
	public void saveToFile (String filename) throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
		writer.write(toString());
		writer.close();
	}
	
	/**
	 * Return a string representation of the puzzle.
	 * @return String a representation of the puzzle
	 */
	public String toString () {
		String part1 = "" + getNumRows() + " " + getNumCols() + System.lineSeparator();
		String part2 = ""; // row projection
		String part3 = ""; // column projection
		String part4 = ""; // grid

		for (int i  = 0; i < numCols; i++) {
			part3 += projectionToString(projectCol(i)) + System.lineSeparator();
		}
		
		for(int i = 0; i < numRows; i ++) {
			String line = "";
			for (int j = 0; j < numCols; j++) {
				if(getCell(i,j) == true) 
					line += FILLED_CELL_CHAR;
				else
					line += EMPTY_CELL_CHAR;	
			}
			part2 += projectionToString(projectRow(i)) + System.lineSeparator();
			part4 += line + System.lineSeparator();			
		}
		
		part4 = part4.substring(0, part4.length() - 1);
		return part1 + part2 + part3 + part4;
	}
	
	private String projectionToString (List<Integer> a) {
		StringJoiner sj = new StringJoiner(" ");
		for (Integer i : a) {
			sj.add(i.toString());
		}
		return sj.toString();
	}
	
	private static boolean[] convertToPrimitiveArray(List<Boolean> booleanList) {       //TA: Ethan Ho
	    boolean[] array = new boolean[booleanList.size()];
	    int i = 0;
	    for(Boolean a: booleanList) {
			array[i] = a;
			i++;
	    }	
	    return array;
	}
	
}